package com.company.main;

public class Main {

    public static void main(String[] args) {
        Cimletezo cimletezo = new Cimletezo();
        System.out.println(cimletezo.cimletezoMethod(12345));
    }
}
