package main.java;

public class Main {

    //parancssor parameter
    public static void main(String[] args) {
        System.out.println(Cimletezo.cimletezoMethod(25, "HUF"));
        System.out.println(Cimletezo.cimletezoMethod(100001, "CUC"));
    }
}
